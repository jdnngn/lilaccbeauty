import { useState, useEffect, useRef } from "react";

// ── DATA ─────────────────────────────────────────────────────────────────────

const SERVICES = [
  {
    id: 1, category: "Full Sets", name: "Classic Full Set",
    duration: "90 min", price: null,
    desc: "Natural-looking individual lashes, perfectly placed to enhance your eye shape. Ideal for an everyday polished look.",
    icon: "✦",
  },
  {
    id: 2, category: "Full Sets", name: "Wispy Set",
    duration: "120 min", price: null,
    desc: "Feathery, textured lashes with a soft spiky finish. The perfect blend of natural and glam — our most requested style.",
    icon: "✦",
  },
  {
    id: 3, category: "Full Sets", name: "Volume Full Set",
    duration: "120 min", price: null,
    desc: "Handmade Russian Volume fans for a full, fluffy, ultra-dramatic look. Crafted with precision for lasting wear.",
    icon: "✦",
  },
  {
    id: 4, category: "Full Sets", name: "Mega Volume Set",
    duration: "150 min", price: null,
    desc: "7D–16D handcrafted fans — maximum drama, maximum impact. For those who want to turn heads.",
    icon: "✦",
  },
  {
    id: 5, category: "Infills", name: "Classic Infill",
    duration: "60 min", price: null,
    desc: "Top up your classic set and keep your lashes looking fresh. Recommended every 2–3 weeks.",
    icon: "◇",
  },
  {
    id: 6, category: "Infills", name: "Volume Infill",
    duration: "75 min", price: null,
    desc: "Refresh your volume or wispy set at the 2–3 week mark for full, seamless lashes.",
    icon: "◇",
  },
  {
    id: 7, category: "Other", name: "Lash Lift & Tint",
    duration: "60 min", price: null,
    desc: "Curl, lift and define your natural lashes for weeks. No extensions needed — just effortlessly gorgeous eyes.",
    icon: "○",
  },
  {
    id: 8, category: "Other", name: "Removal",
    duration: "30 min", price: null,
    desc: "Safe, gentle professional removal of lash extensions with no damage to your natural lashes.",
    icon: "○",
  },
];

const TIME_SLOTS = [
  "9:00 AM","9:30 AM","10:00 AM","10:30 AM","11:00 AM","11:30 AM",
  "12:00 PM","1:00 PM","1:30 PM","2:00 PM","2:30 PM","3:00 PM","3:30 PM","4:00 PM","4:30 PM"
];

const FAQS = [
  { q: "How long do lash extensions last?", a: "With proper aftercare, lash extensions typically last 4–6 weeks following your natural lash cycle. We recommend infills every 2–3 weeks to keep them looking full and fresh." },
  { q: "How should I prepare for my appointment?", a: "Come with clean, makeup-free eyes — especially no mascara or oily products around the eye area. Avoid caffeine beforehand as it can cause eye twitching. Contact lens wearers should bring glasses." },
  { q: "What is aftercare like?", a: "Avoid water and steam for 24–48 hours after your appointment. Use only oil-free cleansers near your eyes, brush daily with a clean spoolie, and avoid rubbing or pulling at your lashes." },
  { q: "Are lash extensions safe?", a: "Absolutely. We use professional-grade, skin-safe adhesives and follow strict hygiene protocols. We always perform a consultation to check for any sensitivities or contraindications before your service." },
  { q: "What's the difference between Classic, Wispy and Volume?", a: "Classic applies one extension per natural lash for a clean, defined look. Volume uses handmade fans (2D–6D) for fullness. Wispy combines both for a textured, feathery effect. We'll help you choose what suits your eyes best." },
  { q: "Do you do a patch test?", a: "If you have sensitive skin or known adhesive sensitivities, we strongly recommend a patch test 24–48 hours before your appointment. Please mention this when booking." },
];

const AFTERCARE = [
  { icon: "💧", title: "Avoid water for 24–48hrs", desc: "Keep lashes dry after your appointment — no steamy showers, saunas or swimming." },
  { icon: "🧴", title: "Use oil-free products", desc: "Oil breaks down lash adhesive. Choose oil-free cleansers and avoid oily makeup removers near the eye area." },
  { icon: "🪄", title: "Brush daily", desc: "Use a clean spoolie each morning to keep your lashes fluffy and tangle-free." },
  { icon: "😴", title: "Sleep on a silk pillowcase", desc: "Reduces friction and helps your lashes last longer between infills." },
  { icon: "🚫", title: "Don't rub or pull", desc: "Rubbing your eyes or picking at lashes can cause premature shedding and damage natural lashes." },
  { icon: "📅", title: "Book infills every 2–3 weeks", desc: "Regular infills keep your set looking full and extend the life of your lashes." },
];

const GALLERY_ITEMS = [
  { style: "Classic", desc: "Clean & defined", gradient: "linear-gradient(135deg, #e8d5f5 0%, #d4b8ef 100%)" },
  { style: "Wispy", desc: "Soft & feathery", gradient: "linear-gradient(135deg, #ddd0f8 0%, #c4a8f0 100%)" },
  { style: "Volume", desc: "Full & fluffy", gradient: "linear-gradient(135deg, #ead4f8 0%, #cea8f0 100%)" },
  { style: "Mega Volume", desc: "Bold & dramatic", gradient: "linear-gradient(135deg, #d8ccf8 0%, #b89eec 100%)" },
  { style: "Wispy Volume", desc: "Textured glam", gradient: "linear-gradient(135deg, #e4d0fa 0%, #c8a4ef 100%)" },
  { style: "Lash Lift", desc: "Natural beauty", gradient: "linear-gradient(135deg, #ecddf8 0%, #d8b8f4 100%)" },
];

const today = new Date();
const getDays = () => {
  const days = [];
  for (let i = 1; i <= 35; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    if (d.getDay() !== 0) days.push(d);
  }
  return days;
};
const fmt = (d) => d.toLocaleDateString("en-AU", { weekday: "short", day: "numeric", month: "short" });

// ── THEME ─────────────────────────────────────────────────────────────────────
const C = {
  violet:    "#6d28d9",
  purple:    "#7c3aed",
  lilac:     "#a78bfa",
  lavender:  "#c4b5fd",
  pale:      "#ede9fe",
  blush:     "#f5f0ff",
  mist:      "#faf8ff",
  ink:       "#1e1028",
  plum:      "#2d1b4e",
  mid:       "#6b5280",
  soft:      "#9d7cbf",
  rule:      "rgba(167,139,250,0.2)",
  glass:     "rgba(255,255,255,0.6)",
  glassBord: "rgba(167,139,250,0.25)",
};

// ── VIEWS / PAGES ─────────────────────────────────────────────────────────────
const VIEWS = { HOME: "home", SERVICES: "services", GALLERY: "gallery", AFTERCARE: "aftercare", FAQ: "faq", BOOK: "book", ADMIN: "admin" };
const STEPS = { SERVICE: 0, DATETIME: 1, DETAILS: 2, CONFIRM: 3 };

// ── COMPONENTS ────────────────────────────────────────────────────────────────
function FloatingOrbs() {
  return (
    <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0, overflow: "hidden" }}>
      <div style={{ position: "absolute", top: "-10%", left: "-5%", width: "50vw", height: "50vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(124,58,237,0.07) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", top: "30%", right: "-10%", width: "40vw", height: "40vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "10%", left: "20%", width: "35vw", height: "35vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(109,40,217,0.05) 0%, transparent 70%)" }} />
    </div>
  );
}

function Marquee() {
  const text = "♡ Handmade Russian Volume Fans &nbsp;&nbsp;·&nbsp;&nbsp; ♡ Customized to Your Eye Shape &nbsp;&nbsp;·&nbsp;&nbsp; ♡ Classic · Volume · Wispy &nbsp;&nbsp;·&nbsp;&nbsp; ♡ Keysborough, Melbourne &nbsp;&nbsp;·&nbsp;&nbsp; ";
  return (
    <div style={{ background: `linear-gradient(135deg, ${C.violet}, ${C.lilac})`, overflow: "hidden", padding: "0.7rem 0", borderBottom: `1px solid ${C.glassBord}` }}>
      <style>{`
        @keyframes marquee { from { transform: translateX(0) } to { transform: translateX(-50%) } }
        .marquee-inner { display: inline-flex; white-space: nowrap; animation: marquee 28s linear infinite; }
      `}</style>
      <div className="marquee-inner">
        {[0,1].map(i => (
          <span key={i} style={{ color: "rgba(255,255,255,0.92)", fontSize: "0.72rem", letterSpacing: "0.15em", textTransform: "uppercase", fontFamily: "inherit" }}
            dangerouslySetInnerHTML={{ __html: text.repeat(4) }} />
        ))}
      </div>
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState(VIEWS.HOME);
  const [step, setStep] = useState(STEPS.SERVICE);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", notes: "" });
  const [bookingDone, setBookingDone] = useState(false);
  const [openFaq, setOpenFaq] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [appointments, setAppointments] = useState([
    { id: 1, name: "Sophie L.", service: "Volume Full Set", date: "Mon 10 Mar", time: "10:00 AM", email: "sophie@email.com", phone: "0412 000 111" },
    { id: 2, name: "Emma R.", service: "Classic Infill", date: "Tue 11 Mar", time: "2:00 PM", email: "emma@email.com", phone: "0412 000 222" },
    { id: 3, name: "Chloe T.", service: "Lash Lift & Tint", date: "Wed 12 Mar", time: "11:30 AM", email: "chloe@email.com", phone: "0412 000 333" },
  ]);
  const [adminSearch, setAdminSearch] = useState("");
  const [serviceFilter, setServiceFilter] = useState("All");
  const [visible, setVisible] = useState(false);

  useEffect(() => { setVisible(false); setTimeout(() => setVisible(true), 60); }, [view]);

  const days = getDays();

  const resetBook = () => {
    setStep(STEPS.SERVICE); setSelectedService(null);
    setSelectedDay(null); setSelectedTime(null);
    setForm({ name: "", email: "", phone: "", notes: "" });
    setBookingDone(false);
  };

  const navigate = (v) => { setView(v); setMobileOpen(false); if (v === VIEWS.BOOK) resetBook(); };

  const handleConfirm = () => {
    setAppointments(prev => [...prev, {
      id: Date.now(), name: form.name, service: selectedService.name,
      date: fmt(selectedDay), time: selectedTime, email: form.email, phone: form.phone,
    }]);
    setBookingDone(true);
  };

  const filteredAppts = appointments.filter(a => {
    const matchSearch = a.name.toLowerCase().includes(adminSearch.toLowerCase()) || a.service.toLowerCase().includes(adminSearch.toLowerCase());
    const matchFilter = serviceFilter === "All" || a.service.includes(serviceFilter);
    return matchSearch && matchFilter;
  });

  const categories = ["All", "Full Set", "Infill", "Lash Lift", "Removal"];

  // ── STYLES ──
  const fadeIn = { opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(14px)", transition: "opacity 0.45s ease, transform 0.45s ease" };

  const nav = {
    wrap: { position: "sticky", top: 0, zIndex: 200, background: "rgba(250,248,255,0.85)", backdropFilter: "blur(18px)", borderBottom: `1px solid ${C.glassBord}` },
    inner: { maxWidth: "1200px", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "1rem 2rem" },
    logo: { display: "flex", flexDirection: "column", cursor: "pointer" },
    logoMain: { fontSize: "1.3rem", fontWeight: 700, fontStyle: "italic", color: C.violet, letterSpacing: "0.03em", lineHeight: 1 },
    logoSub: { fontSize: "0.6rem", letterSpacing: "0.22em", textTransform: "uppercase", color: C.soft, marginTop: "2px" },
    links: { display: "flex", gap: "0.2rem", alignItems: "center" },
    link: (active) => ({
      background: active ? C.pale : "none", border: "none", cursor: "pointer",
      padding: "0.45rem 0.9rem", borderRadius: "50px", fontFamily: "inherit",
      fontSize: "0.78rem", letterSpacing: "0.08em", textTransform: "uppercase",
      color: active ? C.violet : C.soft, fontWeight: active ? 700 : 400,
      transition: "all 0.18s",
    }),
    bookBtn: {
      background: `linear-gradient(135deg, ${C.violet}, ${C.lilac})`,
      border: "none", cursor: "pointer", padding: "0.55rem 1.4rem",
      borderRadius: "50px", fontFamily: "inherit", fontSize: "0.78rem",
      letterSpacing: "0.1em", textTransform: "uppercase", color: "white",
      fontWeight: 700, boxShadow: "0 4px 18px rgba(109,40,217,0.28)",
      transition: "all 0.2s", marginLeft: "0.5rem",
    },
  };

  const btn = {
    primary: { background: `linear-gradient(135deg, ${C.violet}, ${C.lilac})`, border: "none", cursor: "pointer", padding: "1rem 2.6rem", borderRadius: "50px", fontFamily: "inherit", fontSize: "0.85rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "white", fontWeight: 700, boxShadow: `0 8px 28px rgba(109,40,217,0.32)`, transition: "all 0.22s" },
    ghost: { background: "transparent", border: `1.5px solid ${C.glassBord}`, cursor: "pointer", padding: "1rem 2.6rem", borderRadius: "50px", fontFamily: "inherit", fontSize: "0.85rem", letterSpacing: "0.1em", textTransform: "uppercase", color: C.violet, fontWeight: 600, transition: "all 0.22s" },
    back: { background: C.pale, border: "none", cursor: "pointer", padding: "0.8rem 1.8rem", borderRadius: "50px", fontFamily: "inherit", fontSize: "0.8rem", letterSpacing: "0.1em", textTransform: "uppercase", color: C.violet },
    next: (dis) => ({ background: dis ? "#d4c8ef" : `linear-gradient(135deg, ${C.violet}, ${C.lilac})`, border: "none", cursor: dis ? "not-allowed" : "pointer", padding: "0.85rem 2.2rem", borderRadius: "50px", fontFamily: "inherit", fontSize: "0.82rem", letterSpacing: "0.1em", textTransform: "uppercase", color: "white", fontWeight: 700, boxShadow: dis ? "none" : `0 6px 22px rgba(109,40,217,0.3)`, transition: "all 0.2s" }),
  };

  const card = (sel) => ({
    background: sel ? `linear-gradient(135deg, rgba(109,40,217,0.09), rgba(167,139,250,0.06))` : C.glass,
    border: sel ? `2px solid ${C.purple}` : `1.5px solid ${C.glassBord}`,
    borderRadius: "20px", padding: "1.8rem", cursor: "pointer", backdropFilter: "blur(12px)",
    transition: "all 0.22s", boxShadow: sel ? `0 8px 32px rgba(109,40,217,0.18)` : `0 2px 16px rgba(109,40,217,0.05)`,
    transform: sel ? "translateY(-2px)" : "none",
  });

  const inputStyle = { width: "100%", padding: "0.9rem 1.1rem", borderRadius: "12px", boxSizing: "border-box", border: `1.5px solid ${C.glassBord}`, background: C.glass, fontSize: "0.95rem", fontFamily: "inherit", color: C.ink, outline: "none", backdropFilter: "blur(8px)", transition: "border 0.2s" };
  const textareaStyle = { ...inputStyle, resize: "vertical", minHeight: "85px" };

  const section = { maxWidth: "1140px", margin: "0 auto", padding: "0 2rem 5rem" };
  const sTitle = { fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 700, fontStyle: "italic", color: C.ink, marginBottom: "0.4rem", lineHeight: 1.1 };
  const sSub = { fontSize: "0.72rem", letterSpacing: "0.2em", textTransform: "uppercase", color: C.lilac, marginBottom: "2.5rem" };

  const stepLabels = ["Service", "Date & Time", "Your Details", "Confirm"];

  function StepBar() {
    return (
      <div style={{ marginBottom: "2.5rem" }}>
        <div style={{ display: "flex", alignItems: "center" }}>
          {stepLabels.map((label, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", flex: i < stepLabels.length - 1 ? 1 : 0 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div style={{
                  width: "36px", height: "36px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "0.82rem", fontWeight: 700, flexShrink: 0,
                  background: step > i ? `linear-gradient(135deg, ${C.violet}, ${C.lilac})` : step === i ? "white" : "rgba(124,58,237,0.07)",
                  border: step >= i ? `2px solid ${C.violet}` : `2px solid ${C.glassBord}`,
                  color: step > i ? "white" : step === i ? C.violet : C.lavender,
                  boxShadow: step === i ? `0 0 0 5px rgba(109,40,217,0.1)` : "none",
                }}>
                  {step > i ? "✓" : i + 1}
                </div>
                <div style={{ fontSize: "0.62rem", letterSpacing: "0.1em", textTransform: "uppercase", color: step === i ? C.violet : C.lavender, marginTop: "0.4rem", whiteSpace: "nowrap" }}>{label}</div>
              </div>
              {i < stepLabels.length - 1 && (
                <div style={{ flex: 1, height: "2px", margin: "0 6px 1.4rem", background: step > i ? `linear-gradient(90deg, ${C.violet}, ${C.lilac})` : C.rule, transition: "background 0.3s" }} />
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ── HOME PAGE ─────────────────────────────────────────────────────────────
  function HomePage() {
    return (
      <div style={fadeIn}>
        {/* Hero */}
        <div style={{ minHeight: "92vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "4rem 2rem 3rem", position: "relative" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", fontSize: "0.72rem", letterSpacing: "0.2em", textTransform: "uppercase", color: C.violet, background: `rgba(109,40,217,0.07)`, border: `1px solid rgba(109,40,217,0.18)`, padding: "0.45rem 1.3rem", borderRadius: "50px", marginBottom: "2.2rem" }}>
            ✦ Melbourne Eyelash Extension Studio
          </div>
          <h1 style={{ fontSize: "clamp(3.5rem, 9vw, 7rem)", fontWeight: 700, fontStyle: "italic", lineHeight: 0.95, color: C.ink, marginBottom: "1.5rem", maxWidth: "800px" }}>
            Wake up<br /><span style={{ background: `linear-gradient(135deg, ${C.violet}, ${C.lilac})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>effortlessly</span><br />beautiful
          </h1>
          <p style={{ fontSize: "1.05rem", color: C.mid, maxWidth: "500px", lineHeight: 1.8, marginBottom: "0.8rem" }}>
            Handmade Russian Volume fans and customized lash sets designed around your unique eye shape — because no two lash sets should look the same.
          </p>
          <div style={{ fontSize: "0.75rem", letterSpacing: "0.18em", textTransform: "uppercase", color: C.soft, marginBottom: "2.8rem" }}>
            📍 Keysborough, Melbourne
          </div>
          <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap", justifyContent: "center" }}>
            <button style={btn.primary} onClick={() => navigate(VIEWS.BOOK)}
              onMouseOver={e => { e.target.style.transform = "translateY(-2px)"; e.target.style.boxShadow = `0 14px 38px rgba(109,40,217,0.42)`; }}
              onMouseOut={e => { e.target.style.transform = "none"; e.target.style.boxShadow = `0 8px 28px rgba(109,40,217,0.32)`; }}>
              Book Now
            </button>
            <button style={btn.ghost} onClick={() => navigate(VIEWS.SERVICES)}
              onMouseOver={e => { e.target.style.background = C.pale; }}
              onMouseOut={e => { e.target.style.background = "transparent"; }}>
              View Services
            </button>
          </div>

          {/* Floating stats */}
          <div style={{ display: "flex", gap: "1.5rem", marginTop: "5rem", flexWrap: "wrap", justifyContent: "center" }}>
            {[["♡", "Handmade Fans", "Russian Volume Specialist"], ["✦", "Customized Sets", "Tailored to Your Eyes"], ["📍", "Keysborough", "Melbourne Studio"]].map(([icon, title, sub]) => (
              <div key={title} style={{ background: C.glass, backdropFilter: "blur(12px)", border: `1px solid ${C.glassBord}`, borderRadius: "16px", padding: "1.2rem 1.8rem", textAlign: "center", minWidth: "150px" }}>
                <div style={{ fontSize: "1.4rem", marginBottom: "0.3rem" }}>{icon}</div>
                <div style={{ fontWeight: 700, color: C.ink, fontSize: "0.9rem" }}>{title}</div>
                <div style={{ fontSize: "0.72rem", color: C.soft, letterSpacing: "0.05em" }}>{sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Services preview */}
        <div style={{ ...section, paddingTop: "2rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "2.5rem", flexWrap: "wrap", gap: "1rem" }}>
            <div>
              <div style={sTitle}>Our Services</div>
              <div style={sSub}>Classic · Volume · Wispy</div>
            </div>
            <button style={{ ...btn.ghost, padding: "0.7rem 1.5rem", fontSize: "0.75rem" }} onClick={() => navigate(VIEWS.SERVICES)}>See All →</button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: "1.2rem" }}>
            {SERVICES.slice(0, 4).map(sv => (
              <div key={sv.id} style={card(false)}
                onMouseOver={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = `0 12px 36px rgba(109,40,217,0.14)`; }}
                onMouseOut={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = `0 2px 16px rgba(109,40,217,0.05)`; }}>
                <div style={{ fontSize: "0.7rem", letterSpacing: "0.15em", textTransform: "uppercase", color: C.lilac, marginBottom: "0.6rem" }}>{sv.category}</div>
                <div style={{ fontSize: "1.15rem", fontWeight: 700, color: C.ink, marginBottom: "0.5rem" }}>{sv.name}</div>
                <div style={{ fontSize: "0.88rem", color: C.mid, lineHeight: 1.6, marginBottom: "1.2rem" }}>{sv.desc}</div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ fontSize: "0.82rem", color: C.violet, fontWeight: 600, background: C.pale, padding: "0.25rem 0.8rem", borderRadius: "50px" }}>DM to enquire</div>
                  <div style={{ fontSize: "0.75rem", color: C.soft, background: `rgba(167,139,250,0.1)`, padding: "0.25rem 0.7rem", borderRadius: "12px" }}>{sv.duration}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Why us */}
        <div style={{ background: `linear-gradient(135deg, ${C.violet}, #8b5cf6, ${C.lilac})`, padding: "5rem 2rem", margin: "0 0 0 0", textAlign: "center" }}>
          <div style={{ maxWidth: "900px", margin: "0 auto" }}>
            <div style={{ fontSize: "0.72rem", letterSpacing: "0.2em", textTransform: "uppercase", color: "rgba(255,255,255,0.7)", marginBottom: "1rem" }}>Why Lilacc Beauty</div>
            <div style={{ fontSize: "clamp(2rem, 4vw, 3.2rem)", fontWeight: 700, fontStyle: "italic", color: "white", marginBottom: "3rem", lineHeight: 1.15 }}>
              Lashes that feel like yours
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "2rem" }}>
              {[
                ["🤲", "Handmade Fans", "Every volume set is crafted by hand for the most natural, fluffy finish possible."],
                ["👁️", "Custom Mapped", "We map each set to your unique eye shape, lifestyle and lash goals."],
                ["🌿", "Gentle & Safe", "Skin-safe adhesives, strict hygiene protocols and a thorough consultation every visit."],
                ["💜", "Lasting Results", "Proper technique and premium materials mean your lashes go the distance."],
              ].map(([icon, title, desc]) => (
                <div key={title} style={{ textAlign: "center" }}>
                  <div style={{ fontSize: "2rem", marginBottom: "0.8rem" }}>{icon}</div>
                  <div style={{ fontWeight: 700, color: "white", fontSize: "1rem", marginBottom: "0.4rem" }}>{title}</div>
                  <div style={{ fontSize: "0.85rem", color: "rgba(255,255,255,0.75)", lineHeight: 1.6 }}>{desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Gallery preview */}
        <div style={{ ...section, paddingTop: "5rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "2.5rem", flexWrap: "wrap", gap: "1rem" }}>
            <div>
              <div style={sTitle}>Gallery</div>
              <div style={sSub}>Our work</div>
            </div>
            <button style={{ ...btn.ghost, padding: "0.7rem 1.5rem", fontSize: "0.75rem" }} onClick={() => navigate(VIEWS.GALLERY)}>View All →</button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1rem" }}>
            {GALLERY_ITEMS.slice(0, 3).map((g, i) => (
              <div key={i} style={{ aspectRatio: "3/4", borderRadius: "18px", background: g.gradient, display: "flex", flexDirection: "column", justifyContent: "flex-end", padding: "1.2rem", border: `1px solid ${C.glassBord}`, overflow: "hidden", position: "relative" }}>
                <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "3.5rem", opacity: 0.18 }}>✦</div>
                <div style={{ fontSize: "0.7rem", letterSpacing: "0.15em", textTransform: "uppercase", color: "rgba(109,40,217,0.7)", marginBottom: "0.2rem" }}>{g.desc}</div>
                <div style={{ fontWeight: 700, color: C.plum, fontSize: "1rem" }}>{g.style}</div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Banner */}
        <div style={{ ...section, paddingTop: "0" }}>
          <div style={{ background: C.pale, border: `1.5px solid ${C.glassBord}`, borderRadius: "24px", padding: "3.5rem 3rem", textAlign: "center", backdropFilter: "blur(10px)" }}>
            <div style={{ fontSize: "0.72rem", letterSpacing: "0.2em", textTransform: "uppercase", color: C.lilac, marginBottom: "1rem" }}>Ready to glow?</div>
            <div style={{ fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 700, fontStyle: "italic", color: C.ink, marginBottom: "1rem" }}>Book your lash appointment</div>
            <p style={{ color: C.mid, marginBottom: "2rem", lineHeight: 1.7 }}>DM us on Instagram or book online — we'd love to create your perfect set.</p>
            <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
              <button style={btn.primary} onClick={() => navigate(VIEWS.BOOK)}>Book Online</button>
              <a href="https://instagram.com/lilaccbeauty_" target="_blank" rel="noopener noreferrer" style={{ ...btn.ghost, textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "0.4rem" }}>
                📸 @lilaccbeauty_
              </a>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer style={{ borderTop: `1px solid ${C.rule}`, padding: "2.5rem 2rem", textAlign: "center" }}>
          <div style={{ fontWeight: 700, fontStyle: "italic", color: C.violet, fontSize: "1.2rem", marginBottom: "0.4rem" }}>♡ Lilacc Beauty</div>
          <div style={{ fontSize: "0.75rem", color: C.soft, letterSpacing: "0.1em", marginBottom: "0.8rem" }}>Melbourne Eyelash Extension Studio · Keysborough</div>
          <a href="https://instagram.com/lilaccbeauty_" target="_blank" rel="noopener noreferrer" style={{ fontSize: "0.78rem", color: C.lilac, textDecoration: "none" }}>@lilaccbeauty_</a>
        </footer>
      </div>
    );
  }

  // ── SERVICES PAGE ─────────────────────────────────────────────────────────
  function ServicesPage() {
    const cats = ["Full Sets", "Infills", "Other"];
    return (
      <div style={{ ...fadeIn, ...section, paddingTop: "4rem" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <div style={{ ...sSub, textAlign: "center" }}>What we offer</div>
          <div style={{ ...sTitle, textAlign: "center" }}>Services & Pricing</div>
          <p style={{ color: C.mid, marginTop: "1rem", maxWidth: "480px", margin: "1rem auto 0", lineHeight: 1.7 }}>
            All sets are fully customized to suit your eye shape, lifestyle and lash goals. Pricing available on request — DM us on Instagram.
          </p>
        </div>
        {cats.map(cat => (
          <div key={cat} style={{ marginBottom: "3.5rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1.5rem" }}>
              <div style={{ fontWeight: 700, fontSize: "1.3rem", fontStyle: "italic", color: C.ink }}>{cat}</div>
              <div style={{ flex: 1, height: "1px", background: C.rule }} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "1.2rem" }}>
              {SERVICES.filter(s => s.category === cat).map(sv => (
                <div key={sv.id} style={{ ...card(false), cursor: "default" }}
                  onMouseOver={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = `0 12px 32px rgba(109,40,217,0.13)`; }}
                  onMouseOut={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = `0 2px 16px rgba(109,40,217,0.05)`; }}>
                  <div style={{ fontSize: "1.15rem", fontWeight: 700, color: C.ink, marginBottom: "0.5rem" }}>{sv.name}</div>
                  <div style={{ fontSize: "0.88rem", color: C.mid, lineHeight: 1.6, marginBottom: "1.3rem" }}>{sv.desc}</div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: "0.8rem", color: C.violet, fontStyle: "italic" }}>Price on request</span>
                    <span style={{ fontSize: "0.75rem", color: C.soft, background: `rgba(167,139,250,0.1)`, padding: "0.25rem 0.7rem", borderRadius: "12px" }}>{sv.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        <div style={{ background: C.pale, borderRadius: "20px", padding: "2.5rem", textAlign: "center", border: `1px solid ${C.glassBord}`, marginTop: "2rem" }}>
          <div style={{ fontWeight: 700, fontSize: "1.2rem", fontStyle: "italic", color: C.ink, marginBottom: "0.5rem" }}>Not sure what to book?</div>
          <p style={{ color: C.mid, marginBottom: "1.5rem", lineHeight: 1.6 }}>Send us a DM on Instagram and we'll help you find the perfect set for your eyes.</p>
          <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
            <button style={btn.primary} onClick={() => navigate(VIEWS.BOOK)}>Book Now</button>
            <a href="https://instagram.com/lilaccbeauty_" target="_blank" rel="noopener noreferrer" style={{ ...btn.ghost, textDecoration: "none", display: "inline-flex", alignItems: "center" }}>DM on Instagram</a>
          </div>
        </div>
      </div>
    );
  }

  // ── GALLERY PAGE ──────────────────────────────────────────────────────────
  function GalleryPage() {
    return (
      <div style={{ ...fadeIn, ...section, paddingTop: "4rem" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <div style={{ ...sSub, textAlign: "center" }}>Our work</div>
          <div style={{ ...sTitle, textAlign: "center" }}>Gallery</div>
          <p style={{ color: C.mid, marginTop: "1rem", lineHeight: 1.7 }}>
            Every set is unique. Follow us on{" "}
            <a href="https://instagram.com/lilaccbeauty_" target="_blank" rel="noopener noreferrer" style={{ color: C.violet, textDecoration: "none", fontWeight: 600 }}>@lilaccbeauty_</a>{" "}
            for the latest looks.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "1rem", marginBottom: "3rem" }}>
          {GALLERY_ITEMS.map((g, i) => (
            <div key={i} style={{ aspectRatio: i % 3 === 0 ? "3/4" : "1/1", borderRadius: "18px", background: g.gradient, display: "flex", flexDirection: "column", justifyContent: "flex-end", padding: "1.2rem", border: `1px solid ${C.glassBord}`, overflow: "hidden", position: "relative", transition: "transform 0.22s", cursor: "pointer" }}
              onMouseOver={e => e.currentTarget.style.transform = "scale(1.02)"}
              onMouseOut={e => e.currentTarget.style.transform = "none"}>
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ fontSize: "4rem", opacity: 0.15, fontStyle: "italic", fontWeight: 700 }}>♡</div>
              </div>
              <div style={{ fontSize: "0.65rem", letterSpacing: "0.15em", textTransform: "uppercase", color: `rgba(109,40,217,0.7)` }}>{g.desc}</div>
              <div style={{ fontWeight: 700, color: C.plum, fontSize: "0.95rem" }}>{g.style}</div>
            </div>
          ))}
        </div>
        <div style={{ textAlign: "center", padding: "3rem 2rem", background: C.pale, borderRadius: "20px", border: `1px solid ${C.glassBord}` }}>
          <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>📸</div>
          <div style={{ fontWeight: 700, fontSize: "1.2rem", fontStyle: "italic", color: C.ink, marginBottom: "0.4rem" }}>See more on Instagram</div>
          <p style={{ color: C.mid, marginBottom: "1.5rem" }}>We share new sets regularly — follow along for inspo!</p>
          <a href="https://instagram.com/lilaccbeauty_" target="_blank" rel="noopener noreferrer" style={{ ...btn.primary, textDecoration: "none", display: "inline-block" }}>@lilaccbeauty_</a>
        </div>
      </div>
    );
  }

  // ── AFTERCARE PAGE ────────────────────────────────────────────────────────
  function AftercarePage() {
    return (
      <div style={{ ...fadeIn, ...section, paddingTop: "4rem" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <div style={{ ...sSub, textAlign: "center" }}>Keep them looking gorgeous</div>
          <div style={{ ...sTitle, textAlign: "center" }}>Aftercare Guide</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1.3rem", marginBottom: "4rem" }}>
          {AFTERCARE.map((item, i) => (
            <div key={i} style={{ background: C.glass, backdropFilter: "blur(12px)", border: `1.5px solid ${C.glassBord}`, borderRadius: "20px", padding: "2rem", display: "flex", gap: "1.2rem", alignItems: "flex-start" }}>
              <div style={{ fontSize: "1.8rem", flexShrink: 0 }}>{item.icon}</div>
              <div>
                <div style={{ fontWeight: 700, color: C.ink, marginBottom: "0.4rem", fontSize: "0.95rem" }}>{item.title}</div>
                <div style={{ fontSize: "0.86rem", color: C.mid, lineHeight: 1.65 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Retention tips */}
        <div style={{ background: `linear-gradient(135deg, ${C.violet}15, ${C.lilac}10)`, border: `1.5px solid ${C.glassBord}`, borderRadius: "24px", padding: "3rem" }}>
          <div style={{ fontWeight: 700, fontSize: "1.4rem", fontStyle: "italic", color: C.ink, marginBottom: "0.5rem" }}>Infill Schedule</div>
          <div style={{ fontSize: "0.72rem", letterSpacing: "0.15em", textTransform: "uppercase", color: C.lilac, marginBottom: "1.5rem" }}>Keep your lashes full</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: "1rem" }}>
            {[["2 Weeks", "Ideal", "Maximum fullness, minimal lash shedding."], ["3 Weeks", "Recommended", "Still a great fill, light shedding expected."], ["4+ Weeks", "Full Set advised", "Most lashes will have shed — a new set is recommended."]].map(([time, label, desc]) => (
              <div key={time} style={{ background: C.glass, borderRadius: "14px", padding: "1.3rem", border: `1px solid ${C.glassBord}` }}>
                <div style={{ fontSize: "1.3rem", fontWeight: 700, color: C.violet }}>{time}</div>
                <div style={{ fontSize: "0.72rem", letterSpacing: "0.1em", textTransform: "uppercase", color: C.lilac, margin: "0.2rem 0 0.5rem" }}>{label}</div>
                <div style={{ fontSize: "0.83rem", color: C.mid, lineHeight: 1.5 }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: "3rem" }}>
          <button style={btn.primary} onClick={() => navigate(VIEWS.BOOK)}>Book Your Infill →</button>
        </div>
      </div>
    );
  }

  // ── FAQ PAGE ──────────────────────────────────────────────────────────────
  function FaqPage() {
    return (
      <div style={{ ...fadeIn, ...section, paddingTop: "4rem" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <div style={{ ...sSub, textAlign: "center" }}>Got questions?</div>
          <div style={{ ...sTitle, textAlign: "center" }}>FAQ</div>
        </div>
        <div style={{ maxWidth: "720px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "0.8rem" }}>
          {FAQS.map((faq, i) => (
            <div key={i} style={{ background: C.glass, backdropFilter: "blur(12px)", border: `1.5px solid ${openFaq === i ? C.lilac : C.glassBord}`, borderRadius: "16px", overflow: "hidden", transition: "all 0.2s" }}>
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", padding: "1.3rem 1.5rem", background: "none", border: "none", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: "inherit", textAlign: "left", gap: "1rem" }}>
                <span style={{ fontWeight: 700, color: C.ink, fontSize: "0.95rem" }}>{faq.q}</span>
                <span style={{ color: C.lilac, fontSize: "1.2rem", flexShrink: 0, transition: "transform 0.2s", transform: openFaq === i ? "rotate(45deg)" : "none" }}>+</span>
              </button>
              {openFaq === i && (
                <div style={{ padding: "0 1.5rem 1.3rem", fontSize: "0.9rem", color: C.mid, lineHeight: 1.75 }}>{faq.a}</div>
              )}
            </div>
          ))}
        </div>
        <div style={{ textAlign: "center", marginTop: "3.5rem" }}>
          <p style={{ color: C.mid, marginBottom: "1.5rem" }}>Still have questions? Reach out on Instagram.</p>
          <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
            <button style={btn.primary} onClick={() => navigate(VIEWS.BOOK)}>Book Now</button>
            <a href="https://instagram.com/lilaccbeauty_" target="_blank" rel="noopener noreferrer" style={{ ...btn.ghost, textDecoration: "none", display: "inline-flex", alignItems: "center" }}>DM Us →</a>
          </div>
        </div>
      </div>
    );
  }

  // ── BOOK PAGE ─────────────────────────────────────────────────────────────
  function BookPage() {
    return (
      <div style={{ ...fadeIn, ...section, paddingTop: "4rem" }}>
        {bookingDone ? (
          <div style={{ textAlign: "center", padding: "5rem 2rem" }}>
            <div style={{ fontSize: "5rem", marginBottom: "1.2rem" }}>💜</div>
            <div style={{ fontSize: "2.5rem", fontWeight: 700, fontStyle: "italic", color: C.ink, marginBottom: "0.6rem" }}>You're all booked!</div>
            <p style={{ color: C.mid, lineHeight: 1.8, marginBottom: "2.5rem", fontSize: "1rem" }}>
              Can't wait to see you, <strong>{form.name}</strong>! 🌸<br />
              <strong>{selectedService?.name}</strong> confirmed for <strong>{fmt(selectedDay)}</strong> at <strong>{selectedTime}</strong>.<br />
              📍 Keysborough, Melbourne<br />
              <span style={{ fontSize: "0.88rem" }}>Confirmation sent to {form.email}</span>
            </p>
            <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
              <button style={btn.primary} onClick={() => { setView(VIEWS.BOOK); resetBook(); }}>Book Another</button>
              <button style={btn.ghost} onClick={() => navigate(VIEWS.HOME)}>Back to Home</button>
            </div>
          </div>
        ) : (
          <>
            <div style={{ textAlign: "center", marginBottom: "3rem" }}>
              <div style={{ ...sSub, textAlign: "center" }}>Lilacc Beauty · Keysborough</div>
              <div style={{ ...sTitle, textAlign: "center" }}>Book an Appointment</div>
            </div>
            <div style={{ maxWidth: "860px", margin: "0 auto" }}>
              <StepBar />

              {step === STEPS.SERVICE && (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "1.1rem" }}>
                    {SERVICES.map(sv => (
                      <div key={sv.id} style={card(selectedService?.id === sv.id)} onClick={() => setSelectedService(sv)}>
                        <div style={{ fontSize: "0.68rem", letterSpacing: "0.14em", textTransform: "uppercase", color: C.lilac, marginBottom: "0.5rem" }}>{sv.category}</div>
                        <div style={{ fontSize: "1.1rem", fontWeight: 700, color: C.ink, marginBottom: "0.4rem" }}>{sv.name}</div>
                        <div style={{ fontSize: "0.85rem", color: C.mid, lineHeight: 1.55, marginBottom: "1.1rem" }}>{sv.desc}</div>
                        <div style={{ fontSize: "0.75rem", color: C.soft, background: `rgba(167,139,250,0.1)`, padding: "0.22rem 0.65rem", borderRadius: "12px", display: "inline-block" }}>{sv.duration}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ marginTop: "2rem" }}>
                    <button style={btn.next(!selectedService)} disabled={!selectedService} onClick={() => setStep(STEPS.DATETIME)}>Next →</button>
                  </div>
                </>
              )}

              {step === STEPS.DATETIME && (
                <>
                  <p style={{ fontStyle: "italic", color: C.mid, marginBottom: "1rem" }}>Select a date</p>
                  <div style={{ display: "flex", gap: "0.6rem", overflowX: "auto", paddingBottom: "0.5rem", marginBottom: "2rem" }}>
                    {days.map((d, i) => (
                      <button key={i} onClick={() => { setSelectedDay(d); setSelectedTime(null); }}
                        style={{ minWidth: "74px", padding: "0.85rem 0.5rem", borderRadius: "14px", flexShrink: 0, fontFamily: "inherit", cursor: "pointer", textAlign: "center", transition: "all 0.2s", border: selectedDay?.toDateString() === d.toDateString() ? `2px solid ${C.violet}` : `1.5px solid ${C.glassBord}`, background: selectedDay?.toDateString() === d.toDateString() ? C.pale : C.glass, boxShadow: selectedDay?.toDateString() === d.toDateString() ? `0 4px 16px rgba(109,40,217,0.15)` : "none" }}>
                        <div style={{ fontSize: "0.62rem", letterSpacing: "0.1em", textTransform: "uppercase", color: C.soft }}>{d.toLocaleDateString("en-AU", { weekday: "short" })}</div>
                        <div style={{ fontSize: "1.5rem", fontWeight: 700, color: C.ink }}>{d.getDate()}</div>
                        <div style={{ fontSize: "0.62rem", color: C.soft }}>{d.toLocaleDateString("en-AU", { month: "short" })}</div>
                      </button>
                    ))}
                  </div>
                  {selectedDay && (
                    <>
                      <p style={{ fontStyle: "italic", color: C.mid, marginBottom: "1rem" }}>Select a time</p>
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(95px, 1fr))", gap: "0.55rem", marginBottom: "2rem" }}>
                        {TIME_SLOTS.map(t => (
                          <button key={t} onClick={() => setSelectedTime(t)} style={{ padding: "0.6rem", borderRadius: "10px", fontFamily: "inherit", cursor: "pointer", fontSize: "0.82rem", transition: "all 0.18s", border: selectedTime === t ? `2px solid ${C.violet}` : `1.5px solid ${C.glassBord}`, background: selectedTime === t ? C.pale : C.glass, color: selectedTime === t ? C.violet : C.plum, fontWeight: selectedTime === t ? 700 : 400 }}>{t}</button>
                        ))}
                      </div>
                    </>
                  )}
                  <div style={{ display: "flex", gap: "1rem" }}>
                    <button style={btn.back} onClick={() => setStep(STEPS.SERVICE)}>← Back</button>
                    <button style={btn.next(!selectedDay || !selectedTime)} disabled={!selectedDay || !selectedTime} onClick={() => setStep(STEPS.DETAILS)}>Next →</button>
                  </div>
                </>
              )}

              {step === STEPS.DETAILS && (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                    <input style={inputStyle} placeholder="Full name *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                    <input style={inputStyle} placeholder="Phone number *" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                  </div>
                  <input style={{ ...inputStyle, marginTop: "0" }} placeholder="Email address *" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                  <textarea style={textareaStyle} placeholder="Any notes, allergies, or special requests (optional)" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
                  <div style={{ display: "flex", gap: "1rem", marginTop: "0.5rem" }}>
                    <button style={btn.back} onClick={() => setStep(STEPS.DATETIME)}>← Back</button>
                    <button style={btn.next(!form.name || !form.email || !form.phone)} disabled={!form.name || !form.email || !form.phone} onClick={() => setStep(STEPS.CONFIRM)}>Review →</button>
                  </div>
                </>
              )}

              {step === STEPS.CONFIRM && (
                <>
                  <div style={{ background: C.glass, backdropFilter: "blur(12px)", border: `1.5px solid ${C.glassBord}`, borderRadius: "20px", padding: "2rem", marginBottom: "1.5rem" }}>
                    <div style={{ fontWeight: 700, fontSize: "1.2rem", fontStyle: "italic", color: C.ink, marginBottom: "1.3rem" }}>Booking Summary</div>
                    {[["Service", selectedService?.name], ["Duration", selectedService?.duration], ["Date", fmt(selectedDay)], ["Time", selectedTime], ["Location", "Keysborough, Melbourne"], ["Name", form.name], ["Email", form.email], ["Phone", form.phone], ...(form.notes ? [["Notes", form.notes]] : [])].map(([l, v]) => (
                      <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "0.6rem 0", borderBottom: `1px solid ${C.rule}`, gap: "1rem" }}>
                        <span style={{ color: C.soft, fontStyle: "italic", fontSize: "0.88rem", flexShrink: 0 }}>{l}</span>
                        <span style={{ fontWeight: 600, color: C.ink, fontSize: "0.9rem", textAlign: "right" }}>{v}</span>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: "flex", gap: "1rem" }}>
                    <button style={btn.back} onClick={() => setStep(STEPS.DETAILS)}>← Back</button>
                    <button style={btn.next(false)} onClick={handleConfirm}>Confirm Booking 💜</button>
                  </div>
                </>
              )}
            </div>
          </>
        )}
      </div>
    );
  }

  // ── ADMIN PAGE ────────────────────────────────────────────────────────────
  function AdminPage() {
    const stats = [
      { label: "Total Appointments", value: appointments.length },
      { label: "This Week", value: appointments.filter(a => ["Mon","Tue","Wed","Thu","Fri"].some(d => a.date.startsWith(d))).length },
      { label: "Unique Clients", value: new Set(appointments.map(a => a.email)).size },
    ];
    return (
      <div style={{ ...fadeIn, ...section, paddingTop: "4rem" }}>
        <div style={{ marginBottom: "3rem" }}>
          <div style={sSub}>Lilacc Beauty</div>
          <div style={sTitle}>Admin Dashboard</div>
        </div>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1rem", marginBottom: "3rem" }}>
          {stats.map(s => (
            <div key={s.label} style={{ background: C.glass, backdropFilter: "blur(12px)", border: `1.5px solid ${C.glassBord}`, borderRadius: "18px", padding: "1.5rem" }}>
              <div style={{ fontSize: "2.2rem", fontWeight: 700, color: C.violet, fontStyle: "italic" }}>{s.value}</div>
              <div style={{ fontSize: "0.78rem", color: C.soft, letterSpacing: "0.08em", marginTop: "0.2rem" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Search + filter */}
        <div style={{ display: "flex", gap: "1rem", marginBottom: "1.5rem", flexWrap: "wrap", alignItems: "center" }}>
          <div style={{ position: "relative", flex: 1, minWidth: "220px" }}>
            <span style={{ position: "absolute", left: "1rem", top: "50%", transform: "translateY(-50%)", color: C.lavender }}>🔍</span>
            <input style={{ ...inputStyle, paddingLeft: "2.8rem", marginBottom: 0 }} placeholder="Search by name or service…" value={adminSearch} onChange={e => setAdminSearch(e.target.value)} />
          </div>
          <div style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap" }}>
            {categories.map(cat => (
              <button key={cat} onClick={() => setServiceFilter(cat)} style={{ padding: "0.5rem 1rem", borderRadius: "50px", fontFamily: "inherit", fontSize: "0.75rem", cursor: "pointer", border: `1.5px solid ${serviceFilter === cat ? C.violet : C.glassBord}`, background: serviceFilter === cat ? C.pale : C.glass, color: serviceFilter === cat ? C.violet : C.soft, fontWeight: serviceFilter === cat ? 700 : 400, transition: "all 0.18s" }}>{cat}</button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div style={{ background: C.glass, backdropFilter: "blur(12px)", border: `1.5px solid ${C.glassBord}`, borderRadius: "20px", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: `rgba(109,40,217,0.04)` }}>
                {["Client", "Service", "Date", "Time", "Contact"].map(h => (
                  <th key={h} style={{ textAlign: "left", fontSize: "0.65rem", letterSpacing: "0.14em", textTransform: "uppercase", color: C.violet, padding: "1rem 1.2rem", borderBottom: `1.5px solid ${C.rule}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredAppts.length === 0
                ? <tr><td colSpan={5} style={{ textAlign: "center", color: C.lavender, fontStyle: "italic", padding: "3rem" }}>No appointments found</td></tr>
                : filteredAppts.map(a => (
                  <tr key={a.id} style={{ transition: "background 0.15s" }}
                    onMouseOver={e => e.currentTarget.style.background = `rgba(109,40,217,0.03)`}
                    onMouseOut={e => e.currentTarget.style.background = "transparent"}>
                    <td style={{ padding: "1rem 1.2rem", fontSize: "0.9rem", borderBottom: `1px solid ${C.rule}`, color: C.ink, fontWeight: 700 }}>{a.name}</td>
                    <td style={{ padding: "1rem 1.2rem", borderBottom: `1px solid ${C.rule}` }}>
                      <span style={{ background: `linear-gradient(135deg, rgba(109,40,217,0.1), rgba(167,139,250,0.07))`, color: C.violet, padding: "0.2rem 0.75rem", borderRadius: "12px", fontSize: "0.75rem", fontWeight: 700, border: `1px solid rgba(109,40,217,0.15)` }}>{a.service}</span>
                    </td>
                    <td style={{ padding: "1rem 1.2rem", fontSize: "0.88rem", borderBottom: `1px solid ${C.rule}`, color: C.mid }}>{a.date}</td>
                    <td style={{ padding: "1rem 1.2rem", fontSize: "0.88rem", borderBottom: `1px solid ${C.rule}`, color: C.mid }}>{a.time}</td>
                    <td style={{ padding: "1rem 1.2rem", fontSize: "0.78rem", borderBottom: `1px solid ${C.rule}`, color: C.soft, lineHeight: 1.5 }}>{a.email}<br />{a.phone}</td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ── RENDER ────────────────────────────────────────────────────────────────
  const navItems = [
    { key: VIEWS.HOME, label: "Home" },
    { key: VIEWS.SERVICES, label: "Services" },
    { key: VIEWS.GALLERY, label: "Gallery" },
    { key: VIEWS.AFTERCARE, label: "Aftercare" },
    { key: VIEWS.FAQ, label: "FAQ" },
    { key: VIEWS.ADMIN, label: "Admin" },
  ];

  return (
    <div style={{ fontFamily: "'Playfair Display', Georgia, serif", minHeight: "100vh", background: `linear-gradient(160deg, #f8f5ff 0%, ${C.pale} 40%, #f5f0ff 70%, #f0ebff 100%)`, color: C.ink, position: "relative" }}>
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet" />
      <style>{`* { box-sizing: border-box; } input:focus, textarea:focus { border-color: #7c3aed !important; box-shadow: 0 0 0 3px rgba(124,58,237,0.1); } button:active { transform: scale(0.98); } ::-webkit-scrollbar { width: 6px; height: 6px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: rgba(167,139,250,0.4); border-radius: 3px; }`}</style>
      <FloatingOrbs />
      <Marquee />

      {/* NAV */}
      <nav style={nav.wrap}>
        <div style={nav.inner}>
          <div style={nav.logo} onClick={() => navigate(VIEWS.HOME)}>
            <span style={nav.logoMain}>♡ Lilacc Beauty</span>
            <span style={nav.logoSub}>Melbourne Eyelash Studio</span>
          </div>
          <div style={nav.links}>
            {navItems.map(item => (
              <button key={item.key} style={nav.link(view === item.key)} onClick={() => navigate(item.key)}>{item.label}</button>
            ))}
            <button style={nav.bookBtn} onClick={() => navigate(VIEWS.BOOK)}
              onMouseOver={e => { e.target.style.transform = "translateY(-1px)"; e.target.style.boxShadow = `0 8px 26px rgba(109,40,217,0.4)`; }}
              onMouseOut={e => { e.target.style.transform = "none"; e.target.style.boxShadow = `0 4px 18px rgba(109,40,217,0.28)`; }}>
              Book Now
            </button>
          </div>
        </div>
      </nav>

      {/* PAGE CONTENT */}
      <div style={{ position: "relative", zIndex: 1 }}>
        {view === VIEWS.HOME && <HomePage />}
        {view === VIEWS.SERVICES && <ServicesPage />}
        {view === VIEWS.GALLERY && <GalleryPage />}
        {view === VIEWS.AFTERCARE && <AftercarePage />}
        {view === VIEWS.FAQ && <FaqPage />}
        {view === VIEWS.BOOK && <BookPage />}
        {view === VIEWS.ADMIN && <AdminPage />}
      </div>
    </div>
  );
}
